/* ============================================================
   🎀 INVITO YICHEN — COMPORTAMENTO
   ============================================================
   Non c'è nulla da modificare qui per cambiare testi o colori:
   quelli si trovano in index.html e style.css.
   Questo file gestisce solo: cambio schermata, pulsante RSVP,
   e apertura della busta regalo.
   ============================================================ */
(function () {
  var screens = document.querySelectorAll('.screen');
  var tabs = document.querySelectorAll('.tab[data-goto]');
  var gotoBtns = document.querySelectorAll('[data-goto]');

  // Mostra la schermata con l'id passato e nasconde le altre
  function showScreen(id) {
    screens.forEach(function (s) {
      s.classList.toggle('active', s.id === id);
    });
    tabs.forEach(function (t) {
      t.classList.toggle('active', t.getAttribute('data-goto') === id);
    });
  }

  gotoBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      showScreen(btn.getAttribute('data-goto'));
    });
  });

  /* ---------------- RSVP ---------------- */
  var rsvpBtn = document.getElementById('rsvpBtn');
  var rsvpArea = document.getElementById('rsvpArea');

  function renderConfirmed() {
    rsvpArea.innerHTML =
      '<div class="confirmed-badge">' +
        '<div class="check"><svg width="30" height="30" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="#FF4FA1" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg></div>' +
        '<p>Presenza confermata! Non vediamo l\'ora 🎀</p>' +
        '<button class="btn ghost" id="undoRsvp">Annulla conferma</button>' +
      '</div>';
    document.getElementById('undoRsvp').addEventListener('click', function () {
      try { localStorage.removeItem('yichen-rsvp'); } catch (e) {}
      rsvpArea.innerHTML = '<button class="btn" id="rsvpBtn">Sì, ci saremo!</button>';
      document.getElementById('rsvpBtn').addEventListener('click', confirmRsvp);
    });
  }

  function confirmRsvp() {
    try { localStorage.setItem('yichen-rsvp', 'yes'); } catch (e) {}
    renderConfirmed();
  }

  if (rsvpBtn) rsvpBtn.addEventListener('click', confirmRsvp);

  // Se chi guarda ha già confermato in precedenza (su questo stesso dispositivo/browser), lo ricorda
  try {
    if (localStorage.getItem('yichen-rsvp') === 'yes') renderConfirmed();
  } catch (e) {}

  /* ---------------- Busta regalo ---------------- */
  var envelopeBtn = document.getElementById('envelopeBtn');
  var giftMsg = document.getElementById('giftMsg');

  envelopeBtn.addEventListener('click', function () {
    var open = giftMsg.classList.toggle('open');
    envelopeBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
})();
